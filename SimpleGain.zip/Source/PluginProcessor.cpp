#include "PluginProcessor.h"
#include "PluginEditor.h"

SimpleGainAudioProcessor::SimpleGainAudioProcessor()
    : AudioProcessor (BusesProperties()
#if ! JucePlugin_IsMidiEffect
#if ! JucePlugin_IsSynth
        .withInput  ("Input",  juce::AudioChannelSet::stereo(), true)
#endif
        .withOutput ("Output", juce::AudioChannelSet::stereo(), true)
#endif
        ),
      apvts (*this, nullptr, "PARAMS",
      {
          std::make_unique<juce::AudioParameterFloat>(
              "GAIN", "Gain",
              juce::NormalisableRange<float>(-24.0f, 24.0f, 0.01f),
              0.0f)
      })
{
}

SimpleGainAudioProcessor::~SimpleGainAudioProcessor() {}

const juce::String SimpleGainAudioProcessor::getName() const { return JucePlugin_Name; }
bool SimpleGainAudioProcessor::acceptsMidi() const { return false; }
bool SimpleGainAudioProcessor::producesMidi() const { return false; }
bool SimpleGainAudioProcessor::isMidiEffect() const { return false; }
double SimpleGainAudioProcessor::getTailLengthSeconds() const { return 0.0; }

int SimpleGainAudioProcessor::getNumPrograms() { return 1; }
int SimpleGainAudioProcessor::getCurrentProgram() { return 0; }
void SimpleGainAudioProcessor::setCurrentProgram (int) {}
const juce::String SimpleGainAudioProcessor::getProgramName (int) { return {}; }
void SimpleGainAudioProcessor::changeProgramName (int, const juce::String&) {}

void SimpleGainAudioProcessor::prepareToPlay (double, int) {}
void SimpleGainAudioProcessor::releaseResources() {}

bool SimpleGainAudioProcessor::isBusesLayoutSupported (const BusesLayout& layouts) const
{
    return layouts.getMainOutputChannelSet() == juce::AudioChannelSet::stereo();
}

void SimpleGainAudioProcessor::processBlock (juce::AudioBuffer<float>& buffer,
                                            juce::MidiBuffer&)
{
    juce::ScopedNoDenormals noDenormals;

    float gainDb = *apvts.getRawParameterValue("GAIN");
    float gainLinear = juce::Decibels::decibelsToGain (gainDb);

    for (int ch = 0; ch < buffer.getNumChannels(); ++ch)
        buffer.applyGain (ch, 0, buffer.getNumSamples(), gainLinear);
}

bool SimpleGainAudioProcessor::hasEditor() const { return true; }

juce::AudioProcessorEditor* SimpleGainAudioProcessor::createEditor()
{
    return new SimpleGainAudioProcessorEditor (*this);
}

void SimpleGainAudioProcessor::getStateInformation (juce::MemoryBlock& destData)
{
    juce::MemoryOutputStream stream (destData, true);
    apvts.state.writeToStream (stream);
}

void SimpleGainAudioProcessor::setStateInformation (const void* data, int sizeInBytes)
{
    auto tree = juce::ValueTree::readFromData (data, sizeInBytes);
    if (tree.isValid())
        apvts.replaceState (tree);
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new SimpleGainAudioProcessor();
}
