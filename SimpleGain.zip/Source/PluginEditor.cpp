#include "PluginProcessor.h"
#include "PluginEditor.h"

SimpleGainAudioProcessorEditor::SimpleGainAudioProcessorEditor (SimpleGainAudioProcessor& p)
    : AudioProcessorEditor (&p), processor (p)
{
    setSize (200, 300);

    gainSlider.setSliderStyle (juce::Slider::RotaryVerticalDrag);
    gainSlider.setTextBoxStyle (juce::Slider::TextBoxBelow, false, 60, 20);
    addAndMakeVisible (gainSlider);

    gainAttach = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(
        processor.apvts, "GAIN", gainSlider);
}

SimpleGainAudioProcessorEditor::~SimpleGainAudioProcessorEditor() {}

void SimpleGainAudioProcessorEditor::paint (juce::Graphics& g)
{
    g.fillAll (juce::Colours::black);
}

void SimpleGainAudioProcessorEditor::resized()
{
    gainSlider.setBounds (40, 40, 120, 120);
}
